/*$('button').click(function(){
	$('#content').load('page.html');
});// JavaScript Document*/